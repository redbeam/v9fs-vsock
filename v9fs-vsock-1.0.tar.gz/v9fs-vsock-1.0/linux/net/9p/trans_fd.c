// SPDX-License-Identifier: GPL-2.0-only
/*
 * Fd transport layer.  Includes deprecated socket layer.
 *
 *  Copyright (C) 2006 by Russ Cox <rsc@swtch.com>
 *  Copyright (C) 2004-2005 by Latchesar Ionkov <lucho@ionkov.net>
 *  Copyright (C) 2004-2008 by Eric Van Hensbergen <ericvh@gmail.com>
 *  Copyright (C) 1997-2002 by Ron Minnich <rminnich@sarnoff.com>
 */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/in.h>
#include <linux/in6.h>
#include <linux/module.h>
#include <linux/net.h>
#include <linux/ipv6.h>
#include <linux/kthread.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/un.h>
#include <linux/uaccess.h>
#include <linux/inet.h>
#include <linux/file.h>
#include <linux/fs_context.h>
#include <linux/slab.h>
#include <linux/seq_file.h>
#include <net/9p/9p.h>
#include <net/9p/client.h>
#include <net/9p/transport.h>
#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
#include <linux/vm_sockets.h>
#endif

#include <linux/syscalls.h> /* killme */

#define MAX_SOCK_BUF (1024*1024)
#define MAXPOLLWADDR	2

static struct p9_trans_module p9_tcp_trans;
static struct p9_trans_module p9_fd_trans;
#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
static struct p9_trans_module p9_vsock_trans;
#endif

enum {
	Rworksched = 1,		/* read work scheduled or running */
	Rpending = 2,		/* can read */
	Wworksched = 4,		/* write work scheduled or running */
	Wpending = 8,		/* can write */
};

struct p9_poll_wait {
	struct p9_conn *conn;
	wait_queue_entry_t wait;
	wait_queue_head_t *wait_addr;
};

/**
 * struct p9_conn - fd mux connection state information
 * @mux_list: list link for mux to manage multiple connections (?)
 * @client: reference to client instance for this connection
 * @err: error state
 * @req_lock: lock protecting req_list and requests statuses
 * @req_list: accounting for requests which have been sent
 * @unsent_req_list: accounting for requests that haven't been sent
 * @rreq: read request
 * @wreq: write request
 * @tmp_buf: temporary buffer to read in header
 * @rc: temporary fcall for reading current frame
 * @wpos: write position for current frame
 * @wsize: amount of data to write for current frame
 * @wbuf: current write buffer
 * @poll_pending_link: pending links to be polled per conn
 * @poll_wait: array of wait_q's for various worker threads
 * @pt: poll state
 * @rq: current read work
 * @wq: current write work
 * @wsched: ????
 *
 */

struct p9_conn {
	struct list_head mux_list;
	struct p9_client *client;
	int err;
	spinlock_t req_lock;
	struct list_head req_list;
	struct list_head unsent_req_list;
	struct p9_req_t *rreq;
	struct p9_req_t *wreq;
	char tmp_buf[P9_HDRSZ];
	struct p9_fcall rc;
	int wpos;
	int wsize;
	char *wbuf;
	struct list_head poll_pending_link;
	struct p9_poll_wait poll_wait[MAXPOLLWADDR];
	poll_table pt;
	struct work_struct rq;
	struct work_struct wq;
	unsigned long wsched;
};

/**
 * struct p9_trans_fd - transport state
 * @rd: reference to file to read from
 * @wr: reference of file to write to
 * @conn: connection state reference
 *
 */

struct p9_trans_fd {
	struct file *rd;
	struct file *wr;
	struct p9_conn conn;
};

static void p9_poll_workfn(struct work_struct *work);

static DEFINE_SPINLOCK(p9_poll_lock);
static LIST_HEAD(p9_poll_pending_list);
static DECLARE_WORK(p9_poll_work, p9_poll_workfn);

static unsigned int p9_ipport_resv_min = P9_DEF_MIN_RESVPORT;
static unsigned int p9_ipport_resv_max = P9_DEF_MAX_RESVPORT;

static void p9_mux_poll_stop(struct p9_conn *m)
{
	unsigned long flags;
	int i;

	for (i = 0; i < ARRAY_SIZE(m->poll_wait); i++) {
		struct p9_poll_wait *pwait = &m->poll_wait[i];

		if (pwait->wait_addr) {
			remove_wait_queue(pwait->wait_addr, &pwait->wait);
			pwait->wait_addr = NULL;
		}
	}

	spin_lock_irqsave(&p9_poll_lock, flags);
	list_del_init(&m->poll_pending_link);
	spin_unlock_irqrestore(&p9_poll_lock, flags);

	flush_work(&p9_poll_work);
}

/**
 * p9_conn_cancel - cancel all pending requests with error
 * @m: mux data
 * @err: error code
 *
 */

static void p9_conn_cancel(struct p9_conn *m, int err)
{
	struct p9_req_t *req, *rtmp;
	LIST_HEAD(cancel_list);

	p9_debug(P9_DEBUG_ERROR, "mux %p err %d\n", m, err);

	spin_lock(&m->req_lock);

	if (READ_ONCE(m->err)) {
		spin_unlock(&m->req_lock);
		return;
	}

	WRITE_ONCE(m->err, err);
	ASSERT_EXCLUSIVE_WRITER(m->err);

	list_for_each_entry_safe(req, rtmp, &m->req_list, req_list) {
		list_move(&req->req_list, &cancel_list);
		WRITE_ONCE(req->status, REQ_STATUS_ERROR);
	}
	list_for_each_entry_safe(req, rtmp, &m->unsent_req_list, req_list) {
		list_move(&req->req_list, &cancel_list);
		WRITE_ONCE(req->status, REQ_STATUS_ERROR);
	}

	spin_unlock(&m->req_lock);

	list_for_each_entry_safe(req, rtmp, &cancel_list, req_list) {
		p9_debug(P9_DEBUG_ERROR, "call back req %p\n", req);
		list_del(&req->req_list);
		if (!req->t_err)
			req->t_err = err;
		p9_client_cb(m->client, req, REQ_STATUS_ERROR);
	}
}

static __poll_t
p9_fd_poll(struct p9_client *client, struct poll_table_struct *pt, int *err)
{
	__poll_t ret;
	struct p9_trans_fd *ts = NULL;

	if (client && client->status == Connected)
		ts = client->trans;

	if (!ts) {
		if (err)
			*err = -EREMOTEIO;
		return EPOLLERR;
	}

	ret = vfs_poll(ts->rd, pt);
	if (ts->rd != ts->wr)
		ret = (ret & ~EPOLLOUT) | (vfs_poll(ts->wr, pt) & ~EPOLLIN);
	return ret;
}

/**
 * p9_fd_read- read from a fd
 * @client: client instance
 * @v: buffer to receive data into
 * @len: size of receive buffer
 *
 */

static int p9_fd_read(struct p9_client *client, void *v, int len)
{
	int ret;
	struct p9_trans_fd *ts = NULL;
	loff_t pos;

	if (client && client->status != Disconnected)
		ts = client->trans;

	if (!ts)
		return -EREMOTEIO;

	if (!(ts->rd->f_flags & O_NONBLOCK))
		p9_debug(P9_DEBUG_ERROR, "blocking read ...\n");

	pos = ts->rd->f_pos;
	ret = kernel_read(ts->rd, v, len, &pos);
	if (ret <= 0 && ret != -ERESTARTSYS && ret != -EAGAIN)
		client->status = Disconnected;
	return ret;
}

/**
 * p9_read_work - called when there is some data to be read from a transport
 * @work: container of work to be done
 *
 */

static void p9_read_work(struct work_struct *work)
{
	__poll_t n;
	int err;
	struct p9_conn *m;

	m = container_of(work, struct p9_conn, rq);

	if (READ_ONCE(m->err) < 0)
		return;

	p9_debug(P9_DEBUG_TRANS, "start mux %p pos %zd\n", m, m->rc.offset);

	if (!m->rc.sdata) {
		m->rc.sdata = m->tmp_buf;
		m->rc.offset = 0;
		m->rc.capacity = P9_HDRSZ; /* start by reading header */
	}

	clear_bit(Rpending, &m->wsched);
	p9_debug(P9_DEBUG_TRANS, "read mux %p pos %zd size: %zd = %zd\n",
		 m, m->rc.offset, m->rc.capacity,
		 m->rc.capacity - m->rc.offset);
	err = p9_fd_read(m->client, m->rc.sdata + m->rc.offset,
			 m->rc.capacity - m->rc.offset);
	p9_debug(P9_DEBUG_TRANS, "mux %p got %d bytes\n", m, err);
	if (err == -EAGAIN)
		goto end_clear;

	if (err <= 0)
		goto error;

	m->rc.offset += err;

	/* header read in */
	if ((!m->rreq) && (m->rc.offset == m->rc.capacity)) {
		p9_debug(P9_DEBUG_TRANS, "got new header\n");

		/* Header size */
		m->rc.size = P9_HDRSZ;
		err = p9_parse_header(&m->rc, &m->rc.size, NULL, NULL, 0);
		if (err) {
			p9_debug(P9_DEBUG_ERROR,
				 "error parsing header: %d\n", err);
			goto error;
		}

		p9_debug(P9_DEBUG_TRANS,
			 "mux %p pkt: size: %d bytes tag: %d\n",
			 m, m->rc.size, m->rc.tag);

		m->rreq = p9_tag_lookup(m->client, m->rc.tag);
		if (!m->rreq || (m->rreq->status != REQ_STATUS_SENT)) {
			p9_debug(P9_DEBUG_ERROR, "Unexpected packet tag %d\n",
				 m->rc.tag);
			err = -EIO;
			goto error;
		}

		if (m->rc.size > m->rreq->rc.capacity) {
			p9_debug(P9_DEBUG_ERROR,
				 "requested packet size too big: %d for tag %d with capacity %zd\n",
				 m->rc.size, m->rc.tag, m->rreq->rc.capacity);
			err = -EIO;
			goto error;
		}

		if (!m->rreq->rc.sdata) {
			p9_debug(P9_DEBUG_ERROR,
				 "No recv fcall for tag %d (req %p), disconnecting!\n",
				 m->rc.tag, m->rreq);
			p9_req_put(m->client, m->rreq);
			m->rreq = NULL;
			err = -EIO;
			goto error;
		}
		m->rc.sdata = m->rreq->rc.sdata;
		memcpy(m->rc.sdata, m->tmp_buf, m->rc.capacity);
		m->rc.capacity = m->rc.size;
	}

	/* packet is read in
	 * not an else because some packets (like clunk) have no payload
	 */
	if ((m->rreq) && (m->rc.offset == m->rc.capacity)) {
		p9_debug(P9_DEBUG_TRANS, "got new packet\n");
		m->rreq->rc.size = m->rc.offset;
		spin_lock(&m->req_lock);
		if (m->rreq->status == REQ_STATUS_SENT) {
			list_del(&m->rreq->req_list);
			p9_client_cb(m->client, m->rreq, REQ_STATUS_RCVD);
		} else if (m->rreq->status == REQ_STATUS_FLSHD) {
			/* Ignore replies associated with a cancelled request. */
			p9_debug(P9_DEBUG_TRANS,
				 "Ignore replies associated with a cancelled request\n");
		} else {
			spin_unlock(&m->req_lock);
			p9_debug(P9_DEBUG_ERROR,
				 "Request tag %d errored out while we were reading the reply\n",
				 m->rc.tag);
			err = -EIO;
			goto error;
		}
		spin_unlock(&m->req_lock);
		m->rc.sdata = NULL;
		m->rc.offset = 0;
		m->rc.capacity = 0;
		p9_req_put(m->client, m->rreq);
		m->rreq = NULL;
	}

end_clear:
	clear_bit(Rworksched, &m->wsched);

	if (!list_empty(&m->req_list)) {
		if (test_and_clear_bit(Rpending, &m->wsched))
			n = EPOLLIN;
		else
			n = p9_fd_poll(m->client, NULL, NULL);

		if ((n & EPOLLIN) && !test_and_set_bit(Rworksched, &m->wsched)) {
			p9_debug(P9_DEBUG_TRANS, "sched read work %p\n", m);
			schedule_work(&m->rq);
		}
	}

	return;
error:
	p9_conn_cancel(m, err);
	clear_bit(Rworksched, &m->wsched);
}

/**
 * p9_fd_write - write to a socket
 * @client: client instance
 * @v: buffer to send data from
 * @len: size of send buffer
 *
 */

static int p9_fd_write(struct p9_client *client, void *v, int len)
{
	ssize_t ret;
	struct p9_trans_fd *ts = NULL;

	if (client && client->status != Disconnected)
		ts = client->trans;

	if (!ts)
		return -EREMOTEIO;

	if (!(ts->wr->f_flags & O_NONBLOCK))
		p9_debug(P9_DEBUG_ERROR, "blocking write ...\n");

	ret = kernel_write(ts->wr, v, len, &ts->wr->f_pos);
	if (ret <= 0 && ret != -ERESTARTSYS && ret != -EAGAIN)
		client->status = Disconnected;
	return ret;
}

/**
 * p9_write_work - called when a transport can send some data
 * @work: container for work to be done
 *
 */

static void p9_write_work(struct work_struct *work)
{
	__poll_t n;
	int err;
	struct p9_conn *m;
	struct p9_req_t *req;

	m = container_of(work, struct p9_conn, wq);

	if (READ_ONCE(m->err) < 0) {
		clear_bit(Wworksched, &m->wsched);
		return;
	}

	if (!m->wsize) {
		spin_lock(&m->req_lock);
		if (list_empty(&m->unsent_req_list)) {
			clear_bit(Wworksched, &m->wsched);
			spin_unlock(&m->req_lock);
			return;
		}

		req = list_entry(m->unsent_req_list.next, struct p9_req_t,
			       req_list);
		WRITE_ONCE(req->status, REQ_STATUS_SENT);
		p9_debug(P9_DEBUG_TRANS, "move req %p\n", req);
		list_move_tail(&req->req_list, &m->req_list);

		m->wbuf = req->tc.sdata;
		m->wsize = req->tc.size;
		m->wpos = 0;
		p9_req_get(req);
		m->wreq = req;
		spin_unlock(&m->req_lock);
	}

	p9_debug(P9_DEBUG_TRANS, "mux %p pos %d size %d\n",
		 m, m->wpos, m->wsize);
	clear_bit(Wpending, &m->wsched);
	err = p9_fd_write(m->client, m->wbuf + m->wpos, m->wsize - m->wpos);
	p9_debug(P9_DEBUG_TRANS, "mux %p sent %d bytes\n", m, err);
	if (err == -EAGAIN)
		goto end_clear;


	if (err < 0)
		goto error;
	else if (err == 0) {
		err = -EREMOTEIO;
		goto error;
	}

	m->wpos += err;
	if (m->wpos == m->wsize) {
		m->wpos = m->wsize = 0;
		p9_req_put(m->client, m->wreq);
		m->wreq = NULL;
	}

end_clear:
	clear_bit(Wworksched, &m->wsched);

	if (m->wsize || !list_empty(&m->unsent_req_list)) {
		if (test_and_clear_bit(Wpending, &m->wsched))
			n = EPOLLOUT;
		else
			n = p9_fd_poll(m->client, NULL, NULL);

		if ((n & EPOLLOUT) &&
		   !test_and_set_bit(Wworksched, &m->wsched)) {
			p9_debug(P9_DEBUG_TRANS, "sched write work %p\n", m);
			schedule_work(&m->wq);
		}
	}

	return;

error:
	p9_conn_cancel(m, err);
	clear_bit(Wworksched, &m->wsched);
}

static int p9_pollwake(wait_queue_entry_t *wait, unsigned int mode, int sync, void *key)
{
	struct p9_poll_wait *pwait =
		container_of(wait, struct p9_poll_wait, wait);
	struct p9_conn *m = pwait->conn;
	unsigned long flags;

	spin_lock_irqsave(&p9_poll_lock, flags);
	if (list_empty(&m->poll_pending_link))
		list_add_tail(&m->poll_pending_link, &p9_poll_pending_list);
	spin_unlock_irqrestore(&p9_poll_lock, flags);

	schedule_work(&p9_poll_work);
	return 1;
}

/**
 * p9_pollwait - add poll task to the wait queue
 * @filp: file pointer being polled
 * @wait_address: wait_q to block on
 * @p: poll state
 *
 * called by files poll operation to add v9fs-poll task to files wait queue
 */

static void
p9_pollwait(struct file *filp, wait_queue_head_t *wait_address, poll_table *p)
{
	struct p9_conn *m = container_of(p, struct p9_conn, pt);
	struct p9_poll_wait *pwait = NULL;
	int i;

	for (i = 0; i < ARRAY_SIZE(m->poll_wait); i++) {
		if (m->poll_wait[i].wait_addr == NULL) {
			pwait = &m->poll_wait[i];
			break;
		}
	}

	if (!pwait) {
		p9_debug(P9_DEBUG_ERROR, "not enough wait_address slots\n");
		return;
	}

	pwait->conn = m;
	pwait->wait_addr = wait_address;
	init_waitqueue_func_entry(&pwait->wait, p9_pollwake);
	add_wait_queue(wait_address, &pwait->wait);
}

/**
 * p9_conn_create - initialize the per-session mux data
 * @client: client instance
 *
 * Note: Creates the polling task if this is the first session.
 */

static void p9_conn_create(struct p9_client *client)
{
	__poll_t n;
	struct p9_trans_fd *ts = client->trans;
	struct p9_conn *m = &ts->conn;

	p9_debug(P9_DEBUG_TRANS, "client %p msize %d\n", client, client->msize);

	INIT_LIST_HEAD(&m->mux_list);
	m->client = client;

	spin_lock_init(&m->req_lock);
	INIT_LIST_HEAD(&m->req_list);
	INIT_LIST_HEAD(&m->unsent_req_list);
	INIT_WORK(&m->rq, p9_read_work);
	INIT_WORK(&m->wq, p9_write_work);
	INIT_LIST_HEAD(&m->poll_pending_link);
	init_poll_funcptr(&m->pt, p9_pollwait);

	n = p9_fd_poll(client, &m->pt, NULL);
	if (n & EPOLLIN) {
		p9_debug(P9_DEBUG_TRANS, "mux %p can read\n", m);
		set_bit(Rpending, &m->wsched);
	}

	if (n & EPOLLOUT) {
		p9_debug(P9_DEBUG_TRANS, "mux %p can write\n", m);
		set_bit(Wpending, &m->wsched);
	}
}

/**
 * p9_poll_mux - polls a mux and schedules read or write works if necessary
 * @m: connection to poll
 *
 */

static void p9_poll_mux(struct p9_conn *m)
{
	__poll_t n;
	int err = -ECONNRESET;

	if (READ_ONCE(m->err) < 0)
		return;

	n = p9_fd_poll(m->client, NULL, &err);
	if (n & (EPOLLERR | EPOLLHUP | EPOLLNVAL)) {
		p9_debug(P9_DEBUG_TRANS, "error mux %p err %d\n", m, n);
		p9_conn_cancel(m, err);
	}

	if (n & EPOLLIN) {
		set_bit(Rpending, &m->wsched);
		p9_debug(P9_DEBUG_TRANS, "mux %p can read\n", m);
		if (!test_and_set_bit(Rworksched, &m->wsched)) {
			p9_debug(P9_DEBUG_TRANS, "sched read work %p\n", m);
			schedule_work(&m->rq);
		}
	}

	if (n & EPOLLOUT) {
		set_bit(Wpending, &m->wsched);
		p9_debug(P9_DEBUG_TRANS, "mux %p can write\n", m);
		if ((m->wsize || !list_empty(&m->unsent_req_list)) &&
		    !test_and_set_bit(Wworksched, &m->wsched)) {
			p9_debug(P9_DEBUG_TRANS, "sched write work %p\n", m);
			schedule_work(&m->wq);
		}
	}
}

/**
 * p9_fd_request - send 9P request
 * The function can sleep until the request is scheduled for sending.
 * The function can be interrupted. Return from the function is not
 * a guarantee that the request is sent successfully.
 *
 * @client: client instance
 * @req: request to be sent
 *
 */

static int p9_fd_request(struct p9_client *client, struct p9_req_t *req)
{
	int err;
	struct p9_trans_fd *ts = client->trans;
	struct p9_conn *m = &ts->conn;

	p9_debug(P9_DEBUG_TRANS, "mux %p task %p tcall %p id %d\n",
		 m, current, &req->tc, req->tc.id);

	spin_lock(&m->req_lock);

	err = READ_ONCE(m->err);
	if (err < 0) {
		spin_unlock(&m->req_lock);
		return err;
	}

	WRITE_ONCE(req->status, REQ_STATUS_UNSENT);
	list_add_tail(&req->req_list, &m->unsent_req_list);
	spin_unlock(&m->req_lock);

	p9_poll_mux(m);

	return 0;
}

static int p9_fd_cancel(struct p9_client *client, struct p9_req_t *req)
{
	struct p9_trans_fd *ts = client->trans;
	struct p9_conn *m = &ts->conn;
	int ret = 1;

	p9_debug(P9_DEBUG_TRANS, "client %p req %p\n", client, req);

	spin_lock(&m->req_lock);

	if (req->status == REQ_STATUS_UNSENT) {
		list_del(&req->req_list);
		WRITE_ONCE(req->status, REQ_STATUS_FLSHD);
		p9_req_put(client, req);
		ret = 0;
	}
	spin_unlock(&m->req_lock);

	return ret;
}

static int p9_fd_cancelled(struct p9_client *client, struct p9_req_t *req)
{
	struct p9_trans_fd *ts = client->trans;
	struct p9_conn *m = &ts->conn;

	p9_debug(P9_DEBUG_TRANS, "client %p req %p\n", client, req);

	spin_lock(&m->req_lock);
	/* Ignore cancelled request if status changed since the request was
	 * processed in p9_client_flush()
	*/
	if (req->status != REQ_STATUS_SENT) {
		spin_unlock(&m->req_lock);
		return 0;
	}

	/* we haven't received a response for oldreq,
	 * remove it from the list.
	 */
	list_del(&req->req_list);
	WRITE_ONCE(req->status, REQ_STATUS_FLSHD);
	spin_unlock(&m->req_lock);

	p9_req_put(client, req);

	return 0;
}

static int p9_fd_show_options(struct seq_file *m, struct p9_client *clnt)
{
	if (clnt->trans_mod == &p9_tcp_trans) {
		if (clnt->trans_opts.tcp.port != P9_FD_PORT)
			seq_printf(m, ",port=%u", clnt->trans_opts.tcp.port);
	} else if (clnt->trans_mod == &p9_fd_trans) {
		if (clnt->trans_opts.fd.rfd != ~0)
			seq_printf(m, ",rfd=%u", clnt->trans_opts.fd.rfd);
		if (clnt->trans_opts.fd.wfd != ~0)
			seq_printf(m, ",wfd=%u", clnt->trans_opts.fd.wfd);
	}
#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
	else if (clnt->trans_mod == &p9_vsock_trans) {
		if (clnt->trans_opts.vsock.port != P9_FD_PORT)
			seq_printf(m, ",port=%u", clnt->trans_opts.vsock.port);
	}
#endif
	return 0;
}

static int p9_fd_open(struct p9_client *client, int rfd, int wfd)
{
	struct p9_trans_fd *ts = kzalloc_obj(struct p9_trans_fd);
	if (!ts)
		return -ENOMEM;

	ts->rd = fget(rfd);
	if (!ts->rd)
		goto out_free_ts;
	if (!(ts->rd->f_mode & FMODE_READ))
		goto out_put_rd;
	/* Prevent workers from hanging on IO when fd is a pipe.
	 * It's technically possible for userspace or concurrent mounts to
	 * modify this flag concurrently, which will likely result in a
	 * broken filesystem. However, just having bad flags here should
	 * not crash the kernel or cause any other sort of bug, so mark this
	 * particular data race as intentional so that tooling (like KCSAN)
	 * can allow it and detect further problems.
	 */
	data_race(ts->rd->f_flags |= O_NONBLOCK);
	ts->wr = fget(wfd);
	if (!ts->wr)
		goto out_put_rd;
	if (!(ts->wr->f_mode & FMODE_WRITE))
		goto out_put_wr;
	data_race(ts->wr->f_flags |= O_NONBLOCK);

	client->trans = ts;
	client->status = Connected;

	return 0;

out_put_wr:
	fput(ts->wr);
out_put_rd:
	fput(ts->rd);
out_free_ts:
	kfree(ts);
	return -EIO;
}

static int p9_socket_open(struct p9_client *client, struct socket *csocket)
{
	struct p9_trans_fd *p;
	struct file *file;

	p = kzalloc_obj(struct p9_trans_fd);
	if (!p) {
		sock_release(csocket);
		return -ENOMEM;
	}

	csocket->sk->sk_allocation = GFP_NOIO;
	csocket->sk->sk_use_task_frag = false;
	file = sock_alloc_file(csocket, 0, NULL);
	if (IS_ERR(file)) {
		pr_err("%s (%d): failed to map fd\n",
		       __func__, task_pid_nr(current));
		kfree(p);
		return PTR_ERR(file);
	}

	get_file(file);
	p->wr = p->rd = file;
	client->trans = p;
	client->status = Connected;

	p->rd->f_flags |= O_NONBLOCK;

	p9_conn_create(client);
	return 0;
}

/**
 * p9_conn_destroy - cancels all pending requests of mux
 * @m: mux to destroy
 *
 */

static void p9_conn_destroy(struct p9_conn *m)
{
	p9_debug(P9_DEBUG_TRANS, "mux %p prev %p next %p\n",
		 m, m->mux_list.prev, m->mux_list.next);

	p9_mux_poll_stop(m);
	cancel_work_sync(&m->rq);
	if (m->rreq) {
		p9_req_put(m->client, m->rreq);
		m->rreq = NULL;
	}
	cancel_work_sync(&m->wq);
	if (m->wreq) {
		p9_req_put(m->client, m->wreq);
		m->wreq = NULL;
	}

	p9_conn_cancel(m, -ECONNRESET);

	m->client = NULL;
}

/**
 * p9_fd_close - shutdown file descriptor transport
 * @client: client instance
 *
 */

static void p9_fd_close(struct p9_client *client)
{
	struct p9_trans_fd *ts;

	if (!client)
		return;

	ts = client->trans;
	if (!ts)
		return;

	client->status = Disconnected;

	p9_conn_destroy(&ts->conn);

	if (ts->rd)
		fput(ts->rd);
	if (ts->wr)
		fput(ts->wr);

	kfree(ts);
}

static int p9_bind_privport(struct socket *sock)
{
	struct sockaddr_storage stor = { 0 };
	int port, err = -EINVAL;

	stor.ss_family = sock->ops->family;
	if (stor.ss_family == AF_INET)
		((struct sockaddr_in *)&stor)->sin_addr.s_addr = htonl(INADDR_ANY);
	else
		((struct sockaddr_in6 *)&stor)->sin6_addr = in6addr_any;
	for (port = p9_ipport_resv_max; port >= p9_ipport_resv_min; port--) {
		if (stor.ss_family == AF_INET)
			((struct sockaddr_in *)&stor)->sin_port = htons((ushort)port);
		else
			((struct sockaddr_in6 *)&stor)->sin6_port = htons((ushort)port);
		err = kernel_bind(sock, (struct sockaddr_unsized *)&stor, sizeof(stor));
		if (err != -EADDRINUSE)
			break;
	}
	return err;
}

static int
p9_fd_create_tcp(struct p9_client *client, struct fs_context *fc)
{
	const char *addr = fc->source;
	struct v9fs_context *ctx = fc->fs_private;
	int err;
	char port_str[6];
	struct socket *csocket;
	struct sockaddr_storage stor = { 0 };
	struct p9_fd_opts opts;

	/* opts are already parsed in context */
	opts = ctx->fd_opts;

	if (!addr)
		return -EINVAL;

	sprintf(port_str, "%u", opts.port);
	err = inet_pton_with_scope(current->nsproxy->net_ns, AF_UNSPEC, addr,
				   port_str, &stor);
	if (err < 0)
		return err;

	csocket = NULL;

	client->trans_opts.tcp.port = opts.port;
	client->trans_opts.tcp.privport = opts.privport;
	err = __sock_create(current->nsproxy->net_ns, stor.ss_family,
			    SOCK_STREAM, IPPROTO_TCP, &csocket, 1);
	if (err) {
		pr_err("%s (%d): problem creating socket\n",
		       __func__, task_pid_nr(current));
		return err;
	}

	if (opts.privport) {
		err = p9_bind_privport(csocket);
		if (err < 0) {
			pr_err("%s (%d): problem binding to privport\n",
			       __func__, task_pid_nr(current));
			sock_release(csocket);
			return err;
		}
	}

	err = READ_ONCE(csocket->ops)->connect(csocket,
					       (struct sockaddr_unsized *)&stor,
					       sizeof(stor), 0);
	if (err < 0) {
		pr_err("%s (%d): problem connecting socket to %s\n",
		       __func__, task_pid_nr(current), addr);
		sock_release(csocket);
		return err;
	}

	return p9_socket_open(client, csocket);
}

static int
p9_fd_create_unix(struct p9_client *client, struct fs_context *fc)
{
	const char *addr = fc->source;
	int err;
	struct socket *csocket;
	struct sockaddr_un sun_server;

	csocket = NULL;

	if (!addr || !strlen(addr))
		return -EINVAL;

	if (strlen(addr) >= UNIX_PATH_MAX) {
		pr_err("%s (%d): address too long: %s\n",
		       __func__, task_pid_nr(current), addr);
		return -ENAMETOOLONG;
	}

	sun_server.sun_family = PF_UNIX;
	strcpy(sun_server.sun_path, addr);
	err = __sock_create(current->nsproxy->net_ns, PF_UNIX,
			    SOCK_STREAM, 0, &csocket, 1);
	if (err < 0) {
		pr_err("%s (%d): problem creating socket\n",
		       __func__, task_pid_nr(current));

		return err;
	}
	err = READ_ONCE(csocket->ops)->connect(csocket, (struct sockaddr_unsized *)&sun_server,
					       sizeof(struct sockaddr_un) - 1, 0);
	if (err < 0) {
		pr_err("%s (%d): problem connecting socket: %s: %d\n",
		       __func__, task_pid_nr(current), addr, err);
		sock_release(csocket);
		return err;
	}

	return p9_socket_open(client, csocket);
}

#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
static int
p9_fd_create_vsock(struct p9_client *client, struct fs_context *fc)
{
	const char *addr = fc->source;
	struct v9fs_context *ctx = fc->fs_private;
	int err;
	struct socket *csocket;
	struct sockaddr_vm addr_vm = { 0 };
	struct p9_fd_opts opts;
	unsigned int cid;

	/* opts are already parsed in context */
	opts = ctx->fd_opts;

	if (!addr)
		return -EINVAL;

	/* Parse the CID from the address */
	err = kstrtouint(addr, 10, &cid);
	if (err < 0) {
		pr_err("%s (%d): invalid CID: %s\n",
		       __func__, task_pid_nr(current), addr);
		return err;
	}

	csocket = NULL;

	client->trans_opts.vsock.port = opts.port;
	err = __sock_create(current->nsproxy->net_ns, AF_VSOCK,
			    SOCK_STREAM, 0, &csocket, 1);
	if (err) {
		pr_err("%s (%d): problem creating socket\n",
		       __func__, task_pid_nr(current));
		return err;
	}

	addr_vm.svm_family = AF_VSOCK;
	addr_vm.svm_port = opts.port;
	addr_vm.svm_cid = cid;

	err = READ_ONCE(csocket->ops)->connect(csocket,
					       (struct sockaddr_unsized *)&addr_vm,
					       sizeof(addr_vm), 0);
	if (err < 0) {
		pr_err("%s (%d): problem connecting socket to %s:%u\n",
		       __func__, task_pid_nr(current), addr, opts.port);
		sock_release(csocket);
		return err;
	}

	return p9_socket_open(client, csocket);
}
#endif

static int
p9_fd_create(struct p9_client *client, struct fs_context *fc)
{
	struct v9fs_context *ctx = fc->fs_private;
	struct p9_fd_opts opts = ctx->fd_opts;
	int err;

	client->trans_opts.fd.rfd = opts.rfd;
	client->trans_opts.fd.wfd = opts.wfd;

	if (opts.rfd == ~0 || opts.wfd == ~0) {
		pr_err("Insufficient options for proto=fd\n");
		return -ENOPROTOOPT;
	}

	err = p9_fd_open(client, opts.rfd, opts.wfd);
	if (err < 0)
		return err;

	p9_conn_create(client);

	return 0;
}

static struct p9_trans_module p9_tcp_trans = {
	.name = "tcp",
	.maxsize = MAX_SOCK_BUF,
	.pooled_rbuffers = false,
	.def = false,
	.supports_vmalloc = true,
	.create = p9_fd_create_tcp,
	.close = p9_fd_close,
	.request = p9_fd_request,
	.cancel = p9_fd_cancel,
	.cancelled = p9_fd_cancelled,
	.show_options = p9_fd_show_options,
	.owner = THIS_MODULE,
};
MODULE_ALIAS_9P("tcp");

static struct p9_trans_module p9_unix_trans = {
	.name = "unix",
	.maxsize = MAX_SOCK_BUF,
	.def = false,
	.supports_vmalloc = true,
	.create = p9_fd_create_unix,
	.close = p9_fd_close,
	.request = p9_fd_request,
	.cancel = p9_fd_cancel,
	.cancelled = p9_fd_cancelled,
	.show_options = p9_fd_show_options,
	.owner = THIS_MODULE,
};
MODULE_ALIAS_9P("unix");

static struct p9_trans_module p9_fd_trans = {
	.name = "fd",
	.maxsize = MAX_SOCK_BUF,
	.def = false,
	.supports_vmalloc = true,
	.create = p9_fd_create,
	.close = p9_fd_close,
	.request = p9_fd_request,
	.cancel = p9_fd_cancel,
	.cancelled = p9_fd_cancelled,
	.show_options = p9_fd_show_options,
	.owner = THIS_MODULE,
};
MODULE_ALIAS_9P("fd");

#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
static struct p9_trans_module p9_vsock_trans = {
	.name = "vsock",
	.maxsize = MAX_SOCK_BUF,
	.def = false,
	.supports_vmalloc = true,
	.create = p9_fd_create_vsock,
	.close = p9_fd_close,
	.request = p9_fd_request,
	.cancel = p9_fd_cancel,
	.cancelled = p9_fd_cancelled,
	.show_options = p9_fd_show_options,
	.owner = THIS_MODULE,
};
MODULE_ALIAS_9P("vsock");
#endif

/**
 * p9_poll_workfn - poll worker thread
 * @work: work queue
 *
 * polls all v9fs transports for new events and queues the appropriate
 * work to the work queue
 *
 */

static void p9_poll_workfn(struct work_struct *work)
{
	unsigned long flags;

	p9_debug(P9_DEBUG_TRANS, "start %p\n", current);

	spin_lock_irqsave(&p9_poll_lock, flags);
	while (!list_empty(&p9_poll_pending_list)) {
		struct p9_conn *conn = list_first_entry(&p9_poll_pending_list,
							struct p9_conn,
							poll_pending_link);
		list_del_init(&conn->poll_pending_link);
		spin_unlock_irqrestore(&p9_poll_lock, flags);

		p9_poll_mux(conn);

		spin_lock_irqsave(&p9_poll_lock, flags);
	}
	spin_unlock_irqrestore(&p9_poll_lock, flags);

	p9_debug(P9_DEBUG_TRANS, "finish\n");
}

static int __init p9_trans_fd_init(void)
{
	v9fs_register_trans(&p9_tcp_trans);
	v9fs_register_trans(&p9_unix_trans);
	v9fs_register_trans(&p9_fd_trans);
#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
	v9fs_register_trans(&p9_vsock_trans);
#endif

	return 0;
}

static void __exit p9_trans_fd_exit(void)
{
	flush_work(&p9_poll_work);
	v9fs_unregister_trans(&p9_tcp_trans);
	v9fs_unregister_trans(&p9_unix_trans);
	v9fs_unregister_trans(&p9_fd_trans);
#if IS_ENABLED(CONFIG_NET_9P_VSOCK)
	v9fs_unregister_trans(&p9_vsock_trans);
#endif
}

module_init(p9_trans_fd_init);
module_exit(p9_trans_fd_exit);

MODULE_AUTHOR("Eric Van Hensbergen <ericvh@gmail.com>");
MODULE_DESCRIPTION("Filedescriptor Transport for 9P");
MODULE_LICENSE("GPL");
